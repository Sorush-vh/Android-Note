package ir.sharif.androidsample.compose

data class FieldState(
  var value: String = "",
  val error: String? = null
)
