package ir.sharif.androidsample.data.repository

import ir.sharif.androidsample.data.dto.CreateNoteRequest
import ir.sharif.androidsample.data.dto.NoteDto
import ir.sharif.androidsample.data.dto.UpdateNoteRequest
import ir.sharif.androidsample.data.remote.NotesApi

class NotesRepository(private val api: NotesApi) {
  suspend fun list(): List<NoteDto> = api.list()
  suspend fun create(title: String, desc: String) = api.create(CreateNoteRequest(title, desc))
  suspend fun update(id: String, title: String, desc: String, done: Boolean) =
    api.update(id, UpdateNoteRequest(title, desc, done))
  suspend fun delete(id: String) = api.delete(id)
}
