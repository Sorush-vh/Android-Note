package ir.sharif.androidsample.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.sharif.androidsample.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(private val repo: AuthRepository) : ViewModel() {
  private val _loading = MutableStateFlow(false)
  private val _error = MutableStateFlow<String?>(null)
  val loading: StateFlow<Boolean> = _loading.asStateFlow()
  val error: StateFlow<String?> = _error.asStateFlow()

  fun clearError() { _error.value = null }

  fun login(username: String, password: String, onSuccess: () -> Unit) {
    viewModelScope.launch {
      _loading.value = true
      _error.value = null
      try {
        repo.login(username, password)
        onSuccess()
      } catch (e: Exception) {
        _error.value = e.message ?: "Login failed"
      } finally {
        _loading.value = false
      }
    }
  }

  fun signup(username: String, email: String, first: String, last: String, password: String, onSuccess: () -> Unit) {
    viewModelScope.launch {
      _loading.value = true
      _error.value = null
      try {
        repo.signup(username, email, first, last, password)
        onSuccess()
      } catch (e: Exception) {
        _error.value = e.message ?: "Signup failed"
      } finally {
        _loading.value = false
      }
    }
  }
}
