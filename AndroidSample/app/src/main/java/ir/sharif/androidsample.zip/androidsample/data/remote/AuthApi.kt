package ir.sharif.androidsample.data.remote

import ir.sharif.androidsample.data.dto.*
import retrofit2.http.Body
import retrofit2.http.POST

interface AuthApi {
  @POST("api/accounts/token/")
  suspend fun login(@Body body: LoginRequest): LoginResponse

  @POST("api/accounts/signup/")
  suspend fun signup(@Body body: SignupRequest): Map<String, Any?> // backend returns {"detail": "..."}; we don't use it

  @POST("api/accounts/token/refresh/")
  suspend fun refresh(@Body body: RefreshRequest): RefreshResponse
}
