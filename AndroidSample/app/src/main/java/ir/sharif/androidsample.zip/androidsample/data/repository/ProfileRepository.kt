package ir.sharif.androidsample.data.repository

import ir.sharif.androidsample.data.dto.ProfileDto
import ir.sharif.androidsample.data.dto.UpdateProfileRequest
import ir.sharif.androidsample.data.remote.ProfileApi

class ProfileRepository(private val api: ProfileApi) {
  suspend fun me(): ProfileDto = api.me()
  suspend fun update(first: String?, last: String?, email: String) =
    api.update(UpdateProfileRequest(first, last, email))
}
