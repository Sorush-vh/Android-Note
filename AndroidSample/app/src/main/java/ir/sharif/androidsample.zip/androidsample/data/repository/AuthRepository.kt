package ir.sharif.androidsample.data.repository

import ir.sharif.androidsample.data.dto.*
import ir.sharif.androidsample.data.remote.AuthApi
import ir.sharif.androidsample.data.store.TokenStore

class AuthRepository(
  private val api: AuthApi,
  private val tokens: TokenStore
) {
  suspend fun signup(req: SignupRequest) { api.signup(req) }

  suspend fun login(username: String, password: String) {
    val res = api.login(LoginRequest(username, password))
    tokens.save(res.access, res.refresh)
  }

  suspend fun logout() = tokens.clear()
}
