package ir.sharif.androidsample.di

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import ir.sharif.androidsample.core.network.AuthInterceptor
import ir.sharif.androidsample.core.network.TokenAuthenticator
import ir.sharif.androidsample.core.network.authedRetrofit
import ir.sharif.androidsample.core.network.plainRetrofit
import ir.sharif.androidsample.data.remote.AuthApi
import ir.sharif.androidsample.data.remote.NotesApi
import ir.sharif.androidsample.data.remote.ProfileApi
import ir.sharif.androidsample.data.repository.AuthRepository
import ir.sharif.androidsample.data.repository.NotesRepository
import ir.sharif.androidsample.data.repository.ProfileRepository
import ir.sharif.androidsample.data.store.TokenStore
import ir.sharif.androidsample.ui.auth.AuthViewModel
import ir.sharif.androidsample.ui.notes.NotesViewModel
import ir.sharif.androidsample.ui.profile.ProfileViewModel
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

object ServiceLocator {
  lateinit var tokens: TokenStore; private set
  lateinit var authRepo: AuthRepository; private set
  lateinit var notesRepo: NotesRepository; private set
  lateinit var profileRepo: ProfileRepository; private set

  fun init(ctx: Context) {
    tokens = TokenStore(ctx)

    val plain = plainRetrofit()
    val authApi = plain.create(AuthApi::class.java)

    val client = OkHttpClient.Builder()
      .addInterceptor(AuthInterceptor { tokens.access() })
      .authenticator(TokenAuthenticator(tokens, authApi))
      .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY })
      .build()

    val r = authedRetrofit(client)
    notesRepo = NotesRepository(r.create(NotesApi::class.java))
    profileRepo = ProfileRepository(r.create(ProfileApi::class.java))
    authRepo = AuthRepository(authApi, tokens)
  }

  fun vmFactory() = object : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
      AuthViewModel::class.java -> AuthViewModel(authRepo) as T
      NotesViewModel::class.java -> NotesViewModel(notesRepo) as T
      ProfileViewModel::class.java -> ProfileViewModel(profileRepo, authRepo) as T
      else -> throw IllegalArgumentException("Unknown VM $modelClass")
    }
  }
}
