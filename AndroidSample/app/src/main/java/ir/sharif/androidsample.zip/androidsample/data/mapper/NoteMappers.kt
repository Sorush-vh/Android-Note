package ir.sharif.androidsample.data.mapper

import ir.sharif.androidsample.domain.model.Task
import ir.sharif.androidsample.data.dto.NoteDto

fun NoteDto.toTask() = Task(
  id = id,
  title = title,
  description = description,
  isDone = is_done
)
