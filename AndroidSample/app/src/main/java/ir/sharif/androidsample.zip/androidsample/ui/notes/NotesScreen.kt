package ir.sharif.androidsample.ui.notes

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.Add
import androidx.compose.material3.icons.filled.Person
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sharif.androidsample.di.ServiceLocator
import ir.sharif.androidsample.ui.components.AddNoteDialog
import ir.sharif.androidsample.ui.components.NotesList

@Composable
fun NotesScreen(
  navToProfile: () -> Unit,
  onLoggedOut: () -> Unit,
  vm: NotesViewModel = viewModel(factory = ServiceLocator.vmFactory())
) {
  val s by vm.state.collectAsState()
  var showAdd by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) { vm.load() }

  Scaffold(
    topBar = {
      SmallTopAppBar(
        title = { Text("Notes") },
        actions = {
          IconButton(onClick = navToProfile) { Icon(Icons.Default.Person, contentDescription = "Profile") }
        }
      )
    },
    floatingActionButton = {
      FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "Add") }
    }
  ) { pad ->
    Column(Modifier.fillMaxSize().padding(pad)) {
      if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
      s.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }

      NotesList(
        items = s.items,
        onToggle = { vm.toggle(it.id) },
        onDelete = { vm.delete(it.id) },
        modifier = Modifier.weight(1f)
      )
    }
  }

  if (showAdd) {
    AddNoteDialog(
      onConfirm = { t, d ->
        if (t.isNotBlank()) vm.add(t, d) { showAdd = false } else showAdd = false
      },
      onDismiss = { showAdd = false }
    )
  }
}
