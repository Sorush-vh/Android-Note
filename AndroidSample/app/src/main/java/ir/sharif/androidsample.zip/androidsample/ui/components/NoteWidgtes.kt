package ir.sharif.androidsample.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sharif.androidsample.data.dto.NoteDto

@Composable
fun NoteCard(
  item: NoteDto,
  onToggle: (NoteDto) -> Unit,
  onDelete: (NoteDto) -> Unit,
  modifier: Modifier = Modifier
) {
  Card(modifier = modifier.fillMaxWidth()) {
    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
      Column(Modifier.weight(1f)) {
        Text(item.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Text(item.description, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
      }
      Spacer(Modifier.width(8.dp))
      Column {
        Checkbox(checked = item.is_done, onCheckedChange = { onToggle(item) })
        TextButton(onClick = { onDelete(item) }) { Text("Delete") }
      }
    }
  }
}

@Composable
fun NotesList(
  items: List<NoteDto>,
  onToggle: (NoteDto) -> Unit,
  onDelete: (NoteDto) -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(modifier) {
    items(items, key = { it.id }) { note ->
      NoteCard(note, onToggle, onDelete, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
    }
  }
}
