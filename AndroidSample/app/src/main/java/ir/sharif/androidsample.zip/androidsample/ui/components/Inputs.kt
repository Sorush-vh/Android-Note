package ir.sharif.androidsample.ui.components

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation

@Composable
fun LabeledTextField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  modifier: Modifier = Modifier,
  singleLine: Boolean = true,
  ime: ImeAction = ImeAction.Next,
  onImeAction: (() -> Unit)? = null
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label) },
    singleLine = singleLine,
    modifier = modifier,
    keyboardOptions = KeyboardOptions(imeAction = ime),
    keyboardActions = KeyboardActions(onAny = { onImeAction?.invoke() })
  )
}

@Composable
fun PasswordField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String = "Password",
  modifier: Modifier = Modifier,
  ime: ImeAction = ImeAction.Done,
  onImeAction: (() -> Unit)? = null
) {
  var show by remember { mutableStateOf(false) }
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label) },
    singleLine = true,
    modifier = modifier,
    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
    trailingIcon = {
      TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
    },
    keyboardOptions = KeyboardOptions(imeAction = ime),
    keyboardActions = KeyboardActions(onAny = { onImeAction?.invoke() })
  )
}
