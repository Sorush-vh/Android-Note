package ir.sharif.androidsample.presentation.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.sharif.androidsample.data.repository.NotesRepository
import ir.sharif.androidsample.domain.model.Task
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TaskViewModel(private val repo: NotesRepository) : ViewModel() {
  private val _tasks = MutableStateFlow<List<Task>>(emptyList())
  val tasks: StateFlow<List<Task>> = _tasks.asStateFlow()

  fun refresh() = viewModelScope.launch {
    _tasks.value = repo.list()
  }

  fun addTask(title: String, description: String) = viewModelScope.launch {
    val created = repo.create(title, description)
    _tasks.value = _tasks.value + created
  }

  fun removeTask(id: String) = viewModelScope.launch {
    repo.delete(id)
    _tasks.value = _tasks.value.filterNot { it.id == id }
  }

  fun setDone(id: String, done: Boolean) = viewModelScope.launch {
    val updated = repo.update(id, done = done)
    _tasks.value = _tasks.value.map { if (it.id == id) updated else it }
  }
}
