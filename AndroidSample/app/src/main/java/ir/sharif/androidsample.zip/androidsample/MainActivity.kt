package ir.sharif.androidsample

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import ir.sharif.androidsample.di.ServiceLocator
import ir.sharif.androidsample.ui.auth.LoginScreen
import ir.sharif.androidsample.ui.auth.SignupScreen
import ir.sharif.androidsample.ui.notes.NotesScreen
import ir.sharif.androidsample.ui.profile.ProfileScreen

sealed class Route {
  data object Login : Route()
  data object Signup : Route()
  data object Notes : Route()
  data object Profile : Route()
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContent {
      var route by remember { mutableStateOf<Route>(Route.Login) }

      // Decide initial screen based on token
      LaunchedEffect(Unit) {
        val hasToken = ServiceLocator.tokens.access() != null
        route = if (hasToken) Route.Notes else Route.Login
      }

      when (route) {
        Route.Login -> LoginScreen(
          onLoggedIn = { route = Route.Notes },
          onGoToSignup = { route = Route.Signup }
        )
        Route.Signup -> SignupScreen(
          onDone = { route = Route.Login },
          onBack = { route = Route.Login }
        )
        Route.Notes -> NotesScreen(
          navToProfile = { route = Route.Profile },
          onLoggedOut = { route = Route.Login }
        )
        Route.Profile -> ProfileScreen(
          onBack = { route = Route.Notes },
          onLoggedOut = { route = Route.Login }
        )
      }
    }
  }
}
