package ir.sharif.androidsample.ui.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.sharif.androidsample.data.dto.NoteDto
import ir.sharif.androidsample.data.repository.NotesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class NotesState(
  val loading: Boolean = false,
  val items: List<NoteDto> = emptyList(),
  val error: String? = null
)

class NotesViewModel(private val repo: NotesRepository) : ViewModel() {
  private val _state = MutableStateFlow(NotesState())
  val state = _state.asStateFlow()

  fun load() = viewModelScope.launch {
    _state.value = _state.value.copy(loading = true, error = null)
    runCatching { repo.list() }
      .onSuccess { _state.value = NotesState(items = it) }
      .onFailure { _state.value = NotesState(error = it.message) }
  }

  fun add(title: String, desc: String, after: (() -> Unit)? = null) = viewModelScope.launch {
    runCatching { repo.create(title, desc) }
      .onSuccess { load(); after?.invoke() }
  }

  fun toggle(id: String) = viewModelScope.launch {
    val item = _state.value.items.firstOrNull { it.id == id } ?: return@launch
    runCatching { repo.update(id, item.title, item.description, !item.is_done) }
      .onSuccess { load() }
  }

  fun delete(id: String) = viewModelScope.launch {
    runCatching { repo.delete(id) }.onSuccess { load() }
  }
}
