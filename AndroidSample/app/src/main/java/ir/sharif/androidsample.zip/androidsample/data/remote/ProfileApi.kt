package ir.sharif.androidsample.data.remote

import ir.sharif.androidsample.data.dto.ProfileDto
import ir.sharif.androidsample.data.dto.UpdateProfileRequest
import retrofit2.http.*

interface ProfileApi {
  @GET("api/accounts/me/")
  suspend fun me(): ProfileDto

  @PATCH("api/accounts/me/")
  suspend fun update(@Body body: UpdateProfileRequest): ProfileDto
}
