package ir.sharif.androidsample.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sharif.androidsample.data.dto.SignupRequest
import ir.sharif.androidsample.di.ServiceLocator
import ir.sharif.androidsample.ui.components.LabeledTextField
import ir.sharif.androidsample.ui.components.PasswordField
import ir.sharif.androidsample.ui.components.PrimaryButton

@Composable
fun SignupScreen(
  onDone: () -> Unit,
  onBack: () -> Unit,
  vm: AuthViewModel = viewModel(factory = ServiceLocator.vmFactory())
) {
  val s by vm.state.collectAsState()
  var username by remember { mutableStateOf("") }
  var email by remember { mutableStateOf("") }
  var firstName by remember { mutableStateOf("") }
  var lastName by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }

  Surface {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Column(Modifier.widthIn(max = 500.dp).padding(24.dp)) {
        Text("Create account", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        LabeledTextField(username, { username = it }, "Username", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LabeledTextField(email, { email = it }, "Email", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LabeledTextField(firstName, { firstName = it }, "First name", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LabeledTextField(lastName, { lastName = it }, "Last name", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        PasswordField(password, { password = it }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        PrimaryButton(
          "Sign up",
          onClick = {
            vm.signup(
              SignupRequest(
                username.trim(), password,
                email.trim(),
                first_name = firstName.ifBlank { null },
                last_name = lastName.ifBlank { null }
              ),
              onSuccess = onDone
            )
          },
          modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.End)) { Text("Back to sign in") }

        if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
        s.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
      }
    }
  }
}
