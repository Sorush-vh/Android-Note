package ir.sharif.androidsample.data.dto

data class NoteDto(
  val id: String,
  val title: String,
  val description: String,
  val is_done: Boolean,
  val created_at: String,
  val updated_at: String
)

data class CreateNoteRequest(val title: String, val description: String)
data class UpdateNoteRequest(val title: String, val description: String, val is_done: Boolean)
