package ir.sharif.androidsample.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AddNoteDialog(
  onConfirm: (title: String, desc: String) -> Unit,
  onDismiss: () -> Unit
) {
  var title by remember { mutableStateOf("") }
  var desc by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("New note") },
    text = {
      Column {
        ir.sharif.androidsample.ui.components.LabeledTextField(title, { title = it }, "Title", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        ir.sharif.androidsample.ui.components.LabeledTextField(desc, { desc = it }, "Description", Modifier.fillMaxWidth(), singleLine = false)
      }
    },
    confirmButton = { TextButton(onClick = { onConfirm(title.trim(), desc.trim()) }) { Text("Add") } },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
  )
}
