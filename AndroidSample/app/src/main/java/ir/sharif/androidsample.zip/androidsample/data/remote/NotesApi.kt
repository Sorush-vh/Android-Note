package ir.sharif.androidsample.data.remote

import ir.sharif.androidsample.data.dto.*
import retrofit2.http.*

interface NotesApi {
  @GET("api/notes/")
  suspend fun list(): List<NoteDto>

  @POST("api/notes/")
  suspend fun create(@Body body: CreateNoteRequest): NoteDto

  @GET("api/notes/{id}/")
  suspend fun get(@Path("id") id: String): NoteDto

  @PUT("api/notes/{id}/")
  suspend fun update(@Path("id") id: String, @Body body: UpdateNoteRequest): NoteDto

  @DELETE("api/notes/{id}/")
  suspend fun delete(@Path("id") id: String)
}
