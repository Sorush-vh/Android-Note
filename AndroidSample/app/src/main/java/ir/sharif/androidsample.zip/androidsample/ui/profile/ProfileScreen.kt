package ir.sharif.androidsample.ui.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sharif.androidsample.di.ServiceLocator
import ir.sharif.androidsample.ui.components.LabeledTextField
import ir.sharif.androidsample.ui.components.PrimaryButton
import ir.sharif.androidsample.ui.components.SecondaryButton

@Composable
fun ProfileScreen(
  onBack: () -> Unit,
  onLoggedOut: () -> Unit,
  vm: ProfileViewModel = viewModel(factory = ServiceLocator.vmFactory())
) {
  val s by vm.state.collectAsState()
  var first by remember { mutableStateOf("") }
  var last by remember { mutableStateOf("") }
  var email by remember { mutableStateOf("") }

  LaunchedEffect(Unit) { vm.load() }
  LaunchedEffect(s.data) {
    s.data?.let {
      first = it.first_name.orEmpty()
      last = it.last_name.orEmpty()
      email = it.email
    }
  }

  Scaffold(
    topBar = { SmallTopAppBar(title = { Text("Profile") }) }
  ) { pad ->
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
      if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

      LabeledTextField(first, { first = it }, "First name", Modifier.fillMaxWidth())
      Spacer(Modifier.height(8.dp))
      LabeledTextField(last, { last = it }, "Last name", Modifier.fillMaxWidth())
      Spacer(Modifier.height(8.dp))
      LabeledTextField(email, { email = it }, "Email", Modifier.fillMaxWidth())
      Spacer(Modifier.height(16.dp))

      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PrimaryButton("Save") { vm.update(first.ifBlank { null }, last.ifBlank { null }, email.trim()) }
        SecondaryButton("Back", onBack)
        SecondaryButton("Logout") { vm.logout(onLoggedOut) }
      }

      s.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
    }
  }
}
