package ir.sharif.androidsample.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ir.sharif.androidsample.data.dto.ProfileDto
import ir.sharif.androidsample.data.repository.AuthRepository
import ir.sharif.androidsample.data.repository.ProfileRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProfileState(val loading: Boolean=false, val data: ProfileDto?=null, val error: String?=null)

class ProfileViewModel(
  private val repo: ProfileRepository,
  private val auth: AuthRepository
) : ViewModel() {
  private val _state = MutableStateFlow(ProfileState())
  val state = _state.asStateFlow()

  fun load() = viewModelScope.launch {
    _state.value = ProfileState(loading = true)
    runCatching { repo.me() }
      .onSuccess { _state.value = ProfileState(data = it) }
      .onFailure { _state.value = ProfileState(error = it.message) }
  }

  fun update(first: String?, last: String?, email: String) = viewModelScope.launch {
    runCatching { repo.update(first, last, email) }.onSuccess { _state.value = ProfileState(data = it) }
  }

  fun logout(onDone: () -> Unit) = viewModelScope.launch { auth.logout(); onDone() }
}
